# Kaggriculture simulator — Rust + Rayon (current-source update)

Fast tape-replay port of the Kaggriculture simulator. The game rules are derived from the current `kaggriculture_sim.py` supplied in chat; the sweep/tournament/statistics layer remains Python.

## Current correctness contract implemented

- `episodeSteps=720` means **720 saved states / 719 action turns**. `--steps 720` follows that framework convention.
- Optional `--turns N` means exactly N action turns (equivalent to `--steps N+1`).
- Tape format is canonical `[seat][step]`; both seat streams are preserved. A simple `[step]` tape is also accepted and mirrored to both seats.
- `--reverse-seats` swaps which physical seat each tape plays while keeping rewards in A/B tape order.
- `--trim-hands` replays only `hands[:len(live_hands)]`. Without it, stale helper slots remain visible to the interpreter and can affect atomic PLANT seed-demand validation.
- After a tape ends, its **last action repeats**. To deliberately do nothing, append `{}` to the tape.
- Market state is shared by both players and unit quotes use the same pre-commit market inventory.
- Invalid/malformed market slots are preserved as slots and behave as silent no-ops; they are not filtered out before seat pairing.
- Batch jobs resolve relative tape paths from the CSV directory, parse each unique tape once, run games independently in Rayon, preserve input order, and return `rewards: null` for an errored job. Batch exit code is 1 when any job errored.
- `--threads N` configures Rayon; otherwise `RAYON_NUM_THREADS` / Rayon defaults are used.
- Python-compatible MT19937 seeding is implemented for arbitrary signed 64-bit episode seeds. The per-day seed expression is kept at wider integer precision before being passed to Python-compatible seeding.
- `random.Random(...).randbelow(8)` behavior uses the CPython bit-length/rejection rule, which matters for deterministic shop selection.
- Sparse `marketParams` overrides from the config are supported.

## Build

On a machine with Rust installed:

```powershell
cargo fmt --check
cargo clippy --release -- -D warnings
cargo build --release
```

## Single game

```powershell
.\target\release\kg_sim.exe --tape-a a.json --tape-b b.json --seed 1731182094 --steps 720
```

Or, for an explicit number of action turns:

```powershell
.\target\release\kg_sim.exe --tape-a a.json --tape-b b.json --seed 1731182094 --turns 719
```

Output:

```json
{"rewards":[3000,3000],"errors":[]}
```

## Batch / Rayon

```powershell
.\target\release\kg_sim.exe --jobs jobs.csv --steps 720 --threads 16
```

CSV rows:

```text
seed,tape_a,tape_b,reverse
0,path/a.json,path/b.json,0
1,path/a.json,path/b.json,1
```

Tape paths are relative to the jobs CSV directory. Each unique tape is loaded once and shared read-only between jobs.

## Config

The supplied config defaults are supported: board size 10, 720 episode states, $3000 starting money, 24 turns/day, shed capacity 100, 10 market orders/turn, weed chance 0.005, shop unlock every 3 days, shop consumption every 4 turns, town-center consumption every 24 turns, and farm-hand multiplier 1.

Because the hot-path board is a fixed `[Tile; 100]`, a configured `boardSize` other than 10 is rejected rather than silently simulated incorrectly. Sparse `marketParams` patches are merged onto the built-in defaults.

## Performance design

- fixed 10x10 tile arrays;
- no JSON work inside the simulation loop;
- no tape re-read per batch job;
- no per-turn market `Vec`/order cloning in the hot path;
- integer/enums for game state;
- one RNG per end-of-day, local to the game;
- Rayon parallelism at the outer game level; no global simulation lock.

## Validation status

The source-level audit was updated against the latest handoff supplied here. The environment used to build this archive still has no `rustc`/`cargo`, so I cannot honestly claim a local compiler build or byte-for-byte reference run from this environment.

The Python-side MT19937 implementation was independently checked against CPython for representative seeds including `0`, `1`, `-1`, `2**32`, `-2**63`, and `2**63-1`, including `randrange(8)` / rejection behavior.

Before replacing the Python simulator in production, run the Rust build and compare final rewards plus per-turn snapshots against the real `Environment.run` reference on asymmetric tapes, both seats, and hundreds of seeds.
