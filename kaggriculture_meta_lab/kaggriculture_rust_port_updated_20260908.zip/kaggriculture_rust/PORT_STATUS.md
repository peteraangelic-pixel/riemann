# PORT STATUS

## Source
Rebuilt from the user-supplied `kaggriculture_sim.py` pasted in chat on 2026-09-07, including the complete game-state functions and constants shown there.

## Implemented
- `CROPS`, `ANIMALS`, `PRODUCTS`, market curves and price rounding.
- 10x10 fixed board.
- Farmer/hand movement and unit actions.
- Atomic per-crop PLANT validation.
- Shared market with per-unit lockstep quotes/commits.
- HIRE and BUY_LAND ordering.
- Town shops / town-center consumption.
- Plant watering, growth and decay.
- Animal feeding, care, production, fertilizer and escape.
- Shed capacity, DROP/PICKUP/PLACE overflow behavior.
- End-of-day reset and deterministic Python MT19937-compatible RNG pattern.
- Rayon batch execution with one parse per unique tape and stable input-order output.
- Optional scalar `--config` overrides for the configuration fields exposed by the supplied config.

## Important limitation
The execution environment used to prepare this archive does not provide `rustc` or `cargo`. Therefore the archive has been statically checked for balanced Rust syntax/braces and the Python helper passes `py_compile`, but an actual Rust compiler build and 50+ seed reference cross-check could not be run here.

Before replacing the Python simulator in production, run:

```powershell
cargo build --release
```

then compare the resulting `kg_sim.exe` against the Python simulator on at least 50 fixed seeds using identical decoded tapes. The acceptance target is exact final cash for both seats.
