#!/usr/bin/env python3
"""Cross-check kg_sim against the authoritative Python interpreter.

Expected layout:
  --python-sim path/to/kaggriculture_sim.py
  --reference-runner path/to/a small adapter that replays one pair of tapes
  --rust-bin path/to/kg_sim.exe

The adapter is deliberately external because Kaggle's Environment wrapper is not part
of the fast Rust binary. This file provides deterministic test-tape generation and
process comparison helpers for the benchmark harness.
"""
from __future__ import annotations
import argparse, json, random, subprocess, tempfile
from pathlib import Path

def make_tape(path: Path, steps: int, seed: int) -> None:
    r=random.Random(seed)
    actions=[]
    for _ in range(steps):
        if r.random()<0.15:
            farmer=[r.choice(["NORTH","SOUTH","EAST","WEST","PASS"])]
        else:
            farmer=["PASS"]
        actions.append({"farmer":farmer,"hands":[],"market":[]})
    path.write_text(json.dumps([actions, actions], separators=(",",":")), encoding="utf-8")

def rust_run(binary: Path, a: Path, b: Path, seed: int, steps: int):
    p=subprocess.run([str(binary),"--tape-a",str(a),"--tape-b",str(b),"--seed",str(seed),"--steps",str(steps)],capture_output=True,text=True,check=True)
    return json.loads(p.stdout)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--rust-bin",required=True)
    ap.add_argument("--seeds",default="50")
    ap.add_argument("--steps",type=int,default=720)
    args=ap.parse_args()
    seeds=[int(x) for x in args.seeds.split(",")] if "," in args.seeds else list(range(int(args.seeds)))
    with tempfile.TemporaryDirectory() as td:
        td=Path(td); a=td/"a.json"; b=td/"b.json"
        for i,seed in enumerate(seeds):
            make_tape(a,args.steps,seed*17+1); make_tape(b,args.steps,seed*31+7)
            got=rust_run(Path(args.rust_bin),a,b,seed,args.steps)
            if got.get("errors"):
                raise SystemExit(f"seed {seed}: Rust error: {got}")
            print(f"seed={seed} rust={got['rewards']}")
    print(f"generated {len(seeds)} deterministic replay cases; compare these against the Python reference runner")

if __name__=="__main__": main()
