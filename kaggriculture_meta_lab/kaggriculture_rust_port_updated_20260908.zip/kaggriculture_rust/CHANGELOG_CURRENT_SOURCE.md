# Current-source update — 2026-09-08

Updated the Rust + Rayon port to match the latest handoff/source contract supplied by the user.

## Important fixes

1. **720 states vs 719 actions**: `--steps 720` now executes 719 action turns, matching Kaggle's saved-state indexing.
2. **Seat-aware tapes**: canonical `[seat][step]` tapes retain both seat streams; `--reverse-seats` now selects the correct per-seat action stream.
3. **Tape tail semantics**: after a tape ends, the last action repeats; an explicit `{}` can be appended to stop acting.
4. **`--trim-hands`**: helper actions are clipped to the number of currently live helpers only when requested; PLANT demand validation follows the same rule.
5. **64-bit seed range**: CLI accepts signed 64-bit seeds including `-2**63`; the internal per-day seed expression stays wide enough for Python's arbitrary-precision integer before MT19937 initialization.
6. **CPython `randbelow` parity**: corrected bit-length logic/rejection for `random.choice` of 8 shops.
7. **Market curve**: `sq` is now a distinct curve; MELON/WOOL no longer use `log10` accidentally.
8. **`marketParams`**: sparse config overrides are parsed and merged onto defaults.
9. **Invalid market slots**: malformed orders remain in their original slots instead of being filtered; `HIRE`/`BUY_LAND` accept extra arguments just like the source parser.
10. **Batch errors**: a bad job returns `rewards:null`, good jobs continue, and the process exits with code 1 when any job errored.
11. **CSV paths**: relative tape paths are resolved relative to the jobs CSV directory.
12. **Rayon control**: `--threads N` added; otherwise Rayon honors `RAYON_NUM_THREADS`.
13. **Hot-path allocations**: per-turn market queue/order cloning removed.

## Deliberate optimization boundary

The game board remains a fixed 10x10 `[Tile; 100]` representation. The current handoff explicitly targets that advanced-game size and the zero-allocation hot path.
