use std::fmt;

pub const BOARD: usize = 10;
pub const TILES: usize = BOARD * BOARD;
pub const PRODUCT_COUNT: usize = 9;
pub const CROP_COUNT: usize = 5;
pub const ANIMAL_COUNT: usize = 3;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Crop { Wheat=0, Carrot=1, Tomato=2, Strawberry=3, Melon=4 }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Animal { Goose=0, Cow=1, Sheep=2 }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Product { Wheat=0, Carrot=1, Tomato=2, Strawberry=3, Melon=4, Egg=5, Milk=6, Wool=7, Fertilizer=8 }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Structure { Coop, Pasture }

impl Crop {
    pub fn from_str(s: &str) -> Option<Self> { match s {"WHEAT"=>Some(Self::Wheat),"CARROT"=>Some(Self::Carrot),"TOMATO"=>Some(Self::Tomato),"STRAWBERRY"=>Some(Self::Strawberry),"MELON"=>Some(Self::Melon), _=>None} }
    pub const fn product(self)->Product { match self {Self::Wheat=>Product::Wheat,Self::Carrot=>Product::Carrot,Self::Tomato=>Product::Tomato,Self::Strawberry=>Product::Strawberry,Self::Melon=>Product::Melon} }
}
impl Animal {
    pub fn from_str(s: &str) -> Option<Self> { match s {"GOOSE"=>Some(Self::Goose),"COW"=>Some(Self::Cow),"SHEEP"=>Some(Self::Sheep), _=>None} }
    pub const fn product(self)->Product { match self {Self::Goose=>Product::Egg,Self::Cow=>Product::Milk,Self::Sheep=>Product::Wool} }
    pub const fn structure(self)->Structure { match self {Self::Goose=>Structure::Coop,Self::Cow|Self::Sheep=>Structure::Pasture} }
}
impl Product {
    pub fn from_str(s:&str)->Option<Self>{match s{"WHEAT"=>Some(Self::Wheat),"CARROT"=>Some(Self::Carrot),"TOMATO"=>Some(Self::Tomato),"STRAWBERRY"=>Some(Self::Strawberry),"MELON"=>Some(Self::Melon),"EGG"=>Some(Self::Egg),"MILK"=>Some(Self::Milk),"WOOL"=>Some(Self::Wool),"FERTILIZER"=>Some(Self::Fertilizer), _=>None}}
    pub const fn idx(self)->usize {self as usize}
}

#[derive(Clone, Debug)]
pub enum UnitAction {
    North, South, East, West, Pass,
    PickupProduct(Product, i32), PickupAnimal(Animal, i32), Drop,
    Plant(Crop), Water, Harvest, Fertilize, BuildCoop, BuildPasture, Dig, PlaceProduct(Product, i32), PlaceAnimal(Animal, i32),
    Feed, CollectFertilizer, Care,
}
impl Default for UnitAction { fn default()->Self{Self::Pass} }

#[derive(Clone, Debug)]
pub enum MarketOrder {
    Invalid,
    BuySeed(Crop, i32), BuyProduct(Product, i32), BuyAnimal(Animal, i32), Sell(Product, i32), Hire, BuyLand,
}
#[derive(Clone, Debug, Default)]
pub struct StepAction { pub farmer: UnitAction, pub hands: Vec<UnitAction>, pub market: Vec<MarketOrder> }
#[derive(Clone, Debug, Default)]
pub struct Tape { pub seats: [Vec<StepAction>; 2] }
impl Tape {
    pub fn seat(&self, seat: usize) -> &[StepAction] { &self.seats[seat.min(1)] }
}

#[derive(Clone, Copy, Debug)]
pub struct Plant {
    pub crop: Crop, pub planted_day: i32, pub watered_today: bool,
    pub consecutive_unwatered: i32, pub yield_units: i32, pub max_lifespan_step: i32,
    pub fertilized_until_day: i32,
}
#[derive(Clone, Copy, Debug)]
pub struct AnimalState {
    pub animal: Animal, pub placed_day: i32, pub yield_units: i32,
    pub consecutive_unfed: i32, pub fed_today: bool, pub cared_today: bool,
    pub fertilizer_available: bool, pub pending_care_bonus: i32,
}
#[derive(Clone, Copy, Debug)]
pub enum Tile {
    Empty, Locked, Weed,
    Coop{animal:Option<Animal>, state:Option<AnimalState>},
    Pasture{animal:Option<Animal>, state:Option<AnimalState>},
    Plant(Plant),
}
impl Default for Tile { fn default()->Self{Self::Locked} }

#[derive(Clone, Copy, Debug, Default)]
pub struct Pos { pub x:i32, pub y:i32 }
#[derive(Clone, Copy, Debug, Default)]
pub struct Unit { pub pos: Pos }

#[derive(Clone, Debug)]
pub struct Farm {
    pub money: i64,
    pub tiles: [Tile; TILES],
    pub farmer: Pos,
    pub hands: Vec<Unit>,
    pub hires_today: usize,
    pub unlocked: u8,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct InvKey(pub usize);
#[derive(Clone, Debug)]
pub struct Inventory {
    pub counts: [i32; PRODUCT_COUNT + ANIMAL_COUNT],
    pub keys: Vec<InvKey>,
}
impl Inventory { pub fn new() -> Self { Self { counts: [0; PRODUCT_COUNT + ANIMAL_COUNT], keys: Vec::new() } } }

#[derive(Clone, Debug)]
pub struct Private {
    pub shed: [i32; PRODUCT_COUNT],
    pub animals_in_shed: [i32; ANIMAL_COUNT],
    pub seeds: [i32; CROP_COUNT],
    pub inventories: Vec<Inventory>,
}
impl Private { pub fn new()->Self{Self{shed:[0;PRODUCT_COUNT],animals_in_shed:[0;ANIMAL_COUNT],seeds:[0;CROP_COUNT],inventories:vec![Inventory::new()]}} }

#[derive(Clone, Debug)]
pub struct Market { pub inventory:[i32;PRODUCT_COUNT], pub prices:[i64;PRODUCT_COUNT] }
#[derive(Clone, Debug, Default)]
pub struct Town { pub shops: Vec<Shop> }
#[derive(Clone, Copy, Debug)]
pub enum Shop { Bakery, PizzaShop, BrunchSpot, YarnStore, IceCreamShop, PetCafe, SmoothieShop, FarmersMarket }
impl Shop {
    pub const fn from_sorted_index(i:usize)->Self{match i{0=>Self::Bakery,1=>Self::BrunchSpot,2=>Self::FarmersMarket,3=>Self::IceCreamShop,4=>Self::PetCafe,5=>Self::PizzaShop,6=>Self::SmoothieShop,_=>Self::YarnStore}}
    pub const fn products(self)->&'static [Product]{match self{Self::Bakery=>&[Product::Egg,Product::Wheat],Self::PizzaShop=>&[Product::Milk,Product::Tomato,Product::Wheat],Self::BrunchSpot=>&[Product::Egg,Product::Wheat,Product::Strawberry],Self::YarnStore=>&[Product::Wool],Self::IceCreamShop=>&[Product::Strawberry,Product::Milk,Product::Wheat],Self::PetCafe=>&[Product::Carrot],Self::SmoothieShop=>&[Product::Strawberry,Product::Milk],Self::FarmersMarket=>&[Product::Wheat,Product::Carrot,Product::Tomato,Product::Strawberry]}}
}

#[derive(Clone, Copy, Debug)]
pub struct MarketOverride {
    pub base: Option<i64>,
    pub i0: Option<i32>,
    pub t: Option<i32>,
    pub below_func: Option<u8>,
    pub below_target: Option<f64>,
    pub above_func: Option<u8>,
    pub above_target: Option<f64>,
}

#[derive(Clone, Copy, Debug)]
pub struct SimConfig {
    pub starting_money: i64,
    pub turns_per_day: usize,
    pub shed_capacity: i32,
    pub max_market_orders: usize,
    pub weed_spawn_chance: f64,
    pub shop_unlock_interval: usize,
    pub shop_sell_interval: usize,
    pub center_sell_interval: usize,
    pub farm_hand_cost_mult: i64,
    pub market_overrides: [Option<MarketOverride>; PRODUCT_COUNT],
}
impl Default for SimConfig {
    fn default()->Self{Self{starting_money:3000,turns_per_day:24,shed_capacity:100,max_market_orders:10,weed_spawn_chance:0.005,shop_unlock_interval:3,shop_sell_interval:4,center_sell_interval:24,farm_hand_cost_mult:1,market_overrides:[None; PRODUCT_COUNT]}}
}

#[derive(Clone, Debug)]
pub struct Game {
    pub farms:[Farm;2], pub privs:[Private;2], pub market:Market, pub town:Town,
    pub step:usize, pub cfg:SimConfig,
}

#[derive(Debug)]
pub struct SimError(pub String);
impl fmt::Display for SimError{fn fmt(&self,f:&mut fmt::Formatter<'_>)->fmt::Result{f.write_str(&self.0)}}
impl std::error::Error for SimError{}
