use crate::{model::*, py_rng::PythonRandom, tape::Tape};

const MAX_SHOPS: usize = 8;
const HINGE_GAIN: f64 = 8.0;

#[derive(Clone, Copy)]
struct CropCfg { seed: i64, first: i32, max_day: i32, interval: i32, max_yield: i32, ongoing: bool }
fn crop_cfg(c: Crop) -> CropCfg {
    match c {
        Crop::Wheat => CropCfg { seed:10, first:2, max_day:4, interval:0, max_yield:6, ongoing:false },
        Crop::Carrot => CropCfg { seed:20, first:2, max_day:3, interval:0, max_yield:4, ongoing:false },
        Crop::Tomato => CropCfg { seed:50, first:8, max_day:8, interval:1, max_yield:4, ongoing:true },
        Crop::Strawberry => CropCfg { seed:100, first:10, max_day:10, interval:2, max_yield:4, ongoing:true },
        Crop::Melon => CropCfg { seed:80, first:10, max_day:12, interval:0, max_yield:6, ongoing:false },
    }
}

#[derive(Clone, Copy)]
struct AnimalCfg { cost: i64, first: i32, interval: i32, max_held: i32 }
fn animal_cfg(a: Animal) -> AnimalCfg {
    match a {
        Animal::Goose => AnimalCfg { cost:300, first:4, interval:1, max_held:4 },
        Animal::Cow => AnimalCfg { cost:400, first:8, interval:2, max_held:6 },
        Animal::Sheep => AnimalCfg { cost:500, first:6, interval:3, max_held:6 },
    }
}

#[derive(Clone, Copy)]
struct MarketCfg { base: i64, i0: i32, t: i32, below: u8, below_target: f64, above: u8, above_target: f64 }
fn market_cfg(p: Product) -> MarketCfg {
    use Product::*;
    match p {
        Wheat => MarketCfg{base:25,i0:10000,t:400,below:2,below_target:0.80,above:3,above_target:0.20},
        Carrot => MarketCfg{base:35,i0:10000,t:450,below:5,below_target:1.00,above:2,above_target:0.70},
        Tomato => MarketCfg{base:60,i0:10000,t:200,below:5,below_target:0.40,above:2,above_target:0.60},
        Strawberry => MarketCfg{base:120,i0:10000,t:100,below:2,below_target:0.70,above:1,above_target:1.60},
        Melon => MarketCfg{base:250,i0:10000,t:300,below:3,below_target:0.20,above:6,above_target:3.60},
        Egg => MarketCfg{base:50,i0:10000,t:332,below:5,below_target:0.40,above:3,above_target:0.20},
        Milk => MarketCfg{base:160,i0:10000,t:122,below:2,below_target:0.60,above:1,above_target:1.60},
        Wool => MarketCfg{base:200,i0:10000,t:105,below:3,below_target:0.20,above:6,above_target:3.20},
        Fertilizer => MarketCfg{base:100,i0:10000,t:200,below:1,below_target:0.40,above:1,above_target:0.40},
    }
}

fn shape(kind: u8, x: f64, t: f64) -> f64 {
    let x = x.max(0.0);
    match kind {
        1 => x,
        2 => x.sqrt(),
        3 => (1.0 + x).ln(),
        4 => (1.0 + x).log10(),
        5 => {
            if t <= 0.0 { x } else {
                let u = x / t;
                u + HINGE_GAIN * (u - 1.0).max(0.0).powi(2)
            }
        }
        6 => x * x,
        _ => x,
    }
}

/// Python's round() for positive finite values: round-half-to-even.
fn py_round(x: f64) -> i64 {
    let floor = x.floor();
    let frac = x - floor;
    if frac < 0.5 { floor as i64 }
    else if frac > 0.5 { (floor + 1.0) as i64 }
    else {
        let n = floor as i64;
        if n & 1 == 0 { n } else { n + 1 }
    }
}

fn market_price(item: Product, inventory: i32, overrides: &[Option<MarketOverride>; PRODUCT_COUNT]) -> i64 {
    let base_cfg = market_cfg(item);
    let ov = overrides[item.idx()];
    let p = MarketCfg {
        base: ov.and_then(|x| x.base).unwrap_or(base_cfg.base),
        i0: ov.and_then(|x| x.i0).unwrap_or(base_cfg.i0),
        t: ov.and_then(|x| x.t).unwrap_or(base_cfg.t),
        below: ov.and_then(|x| x.below_func).unwrap_or(base_cfg.below),
        below_target: ov.and_then(|x| x.below_target).unwrap_or(base_cfg.below_target),
        above: ov.and_then(|x| x.above_func).unwrap_or(base_cfg.above),
        above_target: ov.and_then(|x| x.above_target).unwrap_or(base_cfg.above_target),
    };
    let (kind, target, x, sign) = if inventory < p.i0 {
        (p.below, p.below_target, (p.i0 - inventory) as f64, 1.0)
    } else {
        (p.above, p.above_target, (inventory - p.i0) as f64, -1.0)
    };
    let amp = target * p.base as f64 / shape(kind, p.t as f64, p.t as f64);
    py_round((p.base as f64 + sign * amp * shape(kind, x, p.t as f64)).max(1.0))
}

fn tile_idx(x: i32, y: i32) -> usize { y as usize * BOARD + x as usize }

fn quadrant(x: i32, y: i32) -> u8 {
    let h = (BOARD / 2) as i32;
    if y < h && x < h { 0 } else if y < h { 1 } else if x < h { 2 } else { 3 }
}

fn shed_tiles() -> [Pos; 4] {
    [Pos{x:4,y:4}, Pos{x:5,y:4}, Pos{x:4,y:5}, Pos{x:5,y:5}]
}

fn is_shed_adjacent(pos: Pos) -> bool { shed_tiles().iter().any(|p| p.x == pos.x && p.y == pos.y) }
fn default_spawn() -> Pos { shed_tiles()[0] }

fn new_farm(starting_money: i64) -> Farm {
    let mut tiles = [Tile::Locked; TILES];
    for y in 0..BOARD as i32 {
        for x in 0..BOARD as i32 {
            tiles[tile_idx(x,y)] = if quadrant(x,y) == 0 { Tile::Empty } else { Tile::Locked };
        }
    }
    Farm { money:starting_money, tiles, farmer:default_spawn(), hands:Vec::new(), hires_today:0, unlocked:1 }
}

fn new_market() -> Market {
    let mut market = Market { inventory:[0;PRODUCT_COUNT], prices:[0;PRODUCT_COUNT] };
    for idx in 0..PRODUCT_COUNT {
        let p = Product::from_str(match idx {
            0=>"WHEAT",1=>"CARROT",2=>"TOMATO",3=>"STRAWBERRY",4=>"MELON",5=>"EGG",6=>"MILK",7=>"WOOL",_=>"FERTILIZER"
        }).unwrap();
        let cfg = market_cfg(p);
        market.inventory[idx] = cfg.i0;
        market.prices[idx] = cfg.base;
    }
    market
}

fn new_game(cfg: SimConfig) -> Game {
    Game { farms:[new_farm(cfg.starting_money),new_farm(cfg.starting_money)], privs:[Private::new(),Private::new()], market:new_market(), town:Town::default(), step:0, cfg }
}

fn shed_total(pr: &Private) -> i32 {
    pr.shed.iter().sum::<i32>() + pr.animals_in_shed.iter().sum::<i32>()
}

fn inv_get(pr: &Private, idx: usize, item: Product) -> i32 {
    pr.inventories.get(idx).map(|i| i.counts[item.idx()]).unwrap_or(0)
}

fn inv_add(pr: &mut Private, idx: usize, item: Product, n: i32) {
    if n <= 0 { return; }
    let id = item.idx();
    if let Some(inv) = pr.inventories.get_mut(idx) {
        if inv.counts[id] == 0 { inv.keys.push(InvKey(id)); }
        inv.counts[id] += n;
    }
}

fn inv_take(pr: &mut Private, idx: usize, item: Product, n: i32) -> bool {
    if n <= 0 || inv_get(pr,idx,item) < n { return false; }
    let id = item.idx();
    if let Some(inv) = pr.inventories.get_mut(idx) {
        inv.counts[id] -= n;
        if inv.counts[id] == 0 {
            if let Some(pos) = inv.keys.iter().position(|k| k.0 == id) { inv.keys.remove(pos); }
        }
    }
    true
}

fn animal_inv_get(pr: &Private, idx: usize, animal: Animal) -> i32 {
    pr.inventories.get(idx).map(|i| i.counts[PRODUCT_COUNT + animal as usize]).unwrap_or(0)
}
fn animal_inv_add(pr: &mut Private, idx: usize, animal: Animal, n: i32) {
    if n <= 0 { return; }
    let id = PRODUCT_COUNT + animal as usize;
    if let Some(inv) = pr.inventories.get_mut(idx) {
        if inv.counts[id] == 0 { inv.keys.push(InvKey(id)); }
        inv.counts[id] += n;
    }
}
fn animal_inv_take(pr: &mut Private, idx: usize, animal: Animal, n: i32) -> bool {
    if n <= 0 || animal_inv_get(pr,idx,animal) < n { return false; }
    let id = PRODUCT_COUNT + animal as usize;
    if let Some(inv) = pr.inventories.get_mut(idx) {
        inv.counts[id] -= n;
        if inv.counts[id] == 0 {
            if let Some(pos) = inv.keys.iter().position(|k| k.0 == id) { inv.keys.remove(pos); }
        }
    }
    true
}

fn refresh_prices(market: &mut Market, overrides: &[Option<MarketOverride>; PRODUCT_COUNT]) {
    for idx in 0..PRODUCT_COUNT {
        let item = match idx {
            0=>Product::Wheat,1=>Product::Carrot,2=>Product::Tomato,3=>Product::Strawberry,4=>Product::Melon,
            5=>Product::Egg,6=>Product::Milk,7=>Product::Wool,_=>Product::Fertilizer
        };
        market.prices[idx] = market_price(item, market.inventory[idx], overrides);
    }
}

fn position(farm: &Farm, idx: usize) -> Option<Pos> {
    if idx == 0 { Some(farm.farmer) } else { farm.hands.get(idx-1).map(|u| u.pos) }
}
fn set_position(farm: &mut Farm, idx: usize, pos: Pos) {
    if idx == 0 { farm.farmer = pos; }
    else if let Some(u) = farm.hands.get_mut(idx-1) { u.pos = pos; }
}

fn make_plant(crop: Crop, day: i32, turns_per_day: usize) -> Plant {
    let c = crop_cfg(crop);
    Plant {
        crop,
        planted_day:day,
        watered_today:false,
        consecutive_unwatered:1,
        yield_units:if c.ongoing {0} else {1},
        max_lifespan_step:if c.ongoing {-1} else {(day + c.max_day + 1) * turns_per_day as i32},
        fertilized_until_day:-1,
    }
}
fn make_animal(animal: Animal, day: i32) -> AnimalState {
    AnimalState { animal, placed_day:day, yield_units:0, consecutive_unfed:0, fed_today:false, cared_today:false, fertilizer_available:false, pending_care_bonus:0 }
}

fn do_unit_action(farm: &mut Farm, private: &mut Private, idx: usize, action: &UnitAction, day: i32, turns_per_day: usize, shed_cap: i32) {
    let Some(pos) = position(farm, idx) else { return; };
    match action {
        UnitAction::North => { if pos.y > 0 { set_position(farm,idx,Pos{x:pos.x,y:pos.y-1}); } return; }
        UnitAction::South => { if pos.y + 1 < BOARD as i32 { set_position(farm,idx,Pos{x:pos.x,y:pos.y+1}); } return; }
        UnitAction::East => { if pos.x + 1 < BOARD as i32 { set_position(farm,idx,Pos{x:pos.x+1,y:pos.y}); } return; }
        UnitAction::West => { if pos.x > 0 { set_position(farm,idx,Pos{x:pos.x-1,y:pos.y}); } return; }
        UnitAction::Pass => return,
        _ => {}
    }

    let ti = tile_idx(pos.x,pos.y);
    let tile = farm.tiles[ti];

    match *action {
        UnitAction::Drop => {
            if !is_shed_adjacent(pos) { return; }
            let mut room = (shed_cap - shed_total(private)).max(0);
            let keys = private.inventories.get(idx).map(|i| i.keys.clone()).unwrap_or_default();
            for key in keys {
                let id = key.0;
                let n = private.inventories.get(idx).map(|i| i.counts[id]).unwrap_or(0);
                if n <= 0 { continue; }
                let take = n.min(room);
                if take > 0 {
                    if id < PRODUCT_COUNT { private.shed[id] += take; }
                    else { private.animals_in_shed[id - PRODUCT_COUNT] += take; }
                    room -= take;
                }
                if let Some(inv) = private.inventories.get_mut(idx) { inv.counts[id] = 0; }
            }
            if let Some(inv) = private.inventories.get_mut(idx) { inv.keys.clear(); }
        }
        UnitAction::PickupProduct(item,n) => {
            if !is_shed_adjacent(pos) || n <= 0 { return; }
            let available = private.shed[item.idx()];
            let take = n.min(available);
            if take > 0 { private.shed[item.idx()] -= take; inv_add(private,idx,item,take); }
        }
        UnitAction::PickupAnimal(item,n) => {
            if !is_shed_adjacent(pos) || n <= 0 { return; }
            let available = private.animals_in_shed[item as usize];
            let take = n.min(available);
            if take > 0 { private.animals_in_shed[item as usize] -= take; animal_inv_add(private,idx,item,take); }
        }
        UnitAction::PlaceAnimal(animal, n) => {
            let ok = match tile {
                Tile::Coop{animal:None,..} => animal.structure() == Structure::Coop,
                Tile::Pasture{animal:None,..} => animal.structure() == Structure::Pasture,
                _ => false,
            };
            if ok {
                if animal_inv_take(private,idx,animal,1) {
                    farm.tiles[ti] = match animal.structure() {
                        Structure::Coop => Tile::Coop{animal:Some(animal),state:Some(make_animal(animal,day))},
                        Structure::Pasture => Tile::Pasture{animal:Some(animal),state:Some(make_animal(animal,day))},
                    };
                }
            } else if is_shed_adjacent(pos) {
                let mut left=n;
                let room=(shed_cap-shed_total(private)).max(0);
                left=left.min(room).min(animal_inv_get(private,idx,animal));
                if left>0 && animal_inv_take(private,idx,animal,left) { private.animals_in_shed[animal as usize]+=left; }
            }
        }
        UnitAction::PlaceProduct(item, n) => {
            if !is_shed_adjacent(pos) { return; }
            let room=(shed_cap-shed_total(private)).max(0);
            let take=n.min(room).min(inv_get(private,idx,item));
            if take>0 && inv_take(private,idx,item,take) { private.shed[item.idx()]+=take; }
        }
        UnitAction::Plant(crop) => {
            if !matches!(tile,Tile::Empty) || private.seeds[crop as usize] <= 0 { return; }
            private.seeds[crop as usize] -= 1;
            farm.tiles[ti] = Tile::Plant(make_plant(crop,day,turns_per_day));
        }
        UnitAction::Water => {
            let Tile::Plant(mut plant) = tile else { return; };
            if plant.watered_today { return; }
            plant.watered_today = true;
            let c = crop_cfg(plant.crop);
            if !c.ongoing {
                let age = day - plant.planted_day;
                let window_start = (c.max_day + 1) / 2;
                if window_start <= age && age <= c.max_day {
                    let bonus = if plant.fertilized_until_day >= day {2} else {1};
                    plant.yield_units = (plant.yield_units + bonus).min(c.max_yield);
                }
            }
            farm.tiles[ti] = Tile::Plant(plant);
        }
        UnitAction::Harvest => {
            match tile {
                Tile::Plant(mut plant) => {
                    if plant.yield_units <= 0 { return; }
                    let c = crop_cfg(plant.crop);
                    if day - plant.planted_day < c.first { return; }
                    let units = plant.yield_units;
                    plant.yield_units = 0;
                    inv_add(private,idx,plant.crop.product(),units);
                    farm.tiles[ti] = if c.ongoing { Tile::Plant(plant) } else { Tile::Empty };
                }
                Tile::Coop{animal:Some(animal),state:Some(mut state)} | Tile::Pasture{animal:Some(animal),state:Some(mut state)} => {
                    if state.yield_units <= 0 { return; }
                    let units = state.yield_units;
                    state.yield_units = 0;
                    inv_add(private,idx,animal.product(),units);
                    farm.tiles[ti] = match animal.structure() {
                        Structure::Coop => Tile::Coop{animal:Some(animal),state:Some(state)},
                        Structure::Pasture => Tile::Pasture{animal:Some(animal),state:Some(state)},
                    };
                }
                _ => {}
            }
        }
        UnitAction::Fertilize => {
            let Tile::Plant(mut plant) = tile else { return; };
            if inv_take(private,idx,Product::Fertilizer,1) {
                plant.fertilized_until_day = plant.fertilized_until_day.max(day+2);
                farm.tiles[ti] = Tile::Plant(plant);
            }
        }
        UnitAction::Dig => {
            match tile {
                Tile::Coop{animal:Some(_),..} | Tile::Pasture{animal:Some(_),..} | Tile::Empty | Tile::Locked => {}
                _ => farm.tiles[ti] = Tile::Empty,
            }
        }
        UnitAction::BuildCoop => { if matches!(tile,Tile::Empty) { farm.tiles[ti] = Tile::Coop{animal:None,state:None}; } }
        UnitAction::BuildPasture => { if matches!(tile,Tile::Empty) { farm.tiles[ti] = Tile::Pasture{animal:None,state:None}; } }
        UnitAction::Feed => {
            match tile {
                Tile::Coop{animal:Some(animal),state:Some(mut state)} | Tile::Pasture{animal:Some(animal),state:Some(mut state)} => {
                    if state.fed_today { return; }
                    if inv_take(private,idx,Product::Wheat,1) {
                        state.fed_today = true;
                        farm.tiles[ti] = match animal.structure() {
                            Structure::Coop => Tile::Coop{animal:Some(animal),state:Some(state)},
                            Structure::Pasture => Tile::Pasture{animal:Some(animal),state:Some(state)},
                        };
                    }
                }
                _ => {}
            }
        }
        UnitAction::CollectFertilizer => {
            match tile {
                Tile::Coop{animal:Some(animal),state:Some(mut state)} | Tile::Pasture{animal:Some(animal),state:Some(mut state)} => {
                    if state.fertilizer_available {
                        state.fertilizer_available = false;
                        inv_add(private,idx,Product::Fertilizer,1);
                        farm.tiles[ti] = match animal.structure() {
                            Structure::Coop => Tile::Coop{animal:Some(animal),state:Some(state)},
                            Structure::Pasture => Tile::Pasture{animal:Some(animal),state:Some(state)},
                        };
                    }
                }
                _ => {}
            }
        }
        UnitAction::Care => {
            match tile {
                Tile::Coop{animal:Some(animal),state:Some(mut state)} | Tile::Pasture{animal:Some(animal),state:Some(mut state)} => {
                    if !state.cared_today {
                        state.cared_today = true;
                        farm.tiles[ti] = match animal.structure() {
                            Structure::Coop => Tile::Coop{animal:Some(animal),state:Some(state)},
                            Structure::Pasture => Tile::Pasture{animal:Some(animal),state:Some(state)},
                        };
                    }
                }
                _ => {}
            }
        }
        UnitAction::North | UnitAction::South | UnitAction::East | UnitAction::West | UnitAction::Pass => unreachable!(),
    }
}

fn fib(n: usize) -> i64 {
    let (mut a, mut b) = (1i64,1i64);
    for _ in 0..n { (a,b)=(b,a+b); }
    a
}
fn hire_cost(n: usize, mult: i64) -> i64 { mult * fib(n) }

fn spawn_hand(farm: &Farm) -> Pos {
    let access = shed_tiles();
    let mut counts = [0usize;4];
    let mut account = |pos:Pos| {
        for (i,a) in access.iter().enumerate() { if pos.x == a.x && pos.y == a.y { counts[i] += 1; return; } }
    };
    account(farm.farmer);
    for hand in &farm.hands { account(hand.pos); }
    let mut best=0usize;
    for i in 1..4 { if counts[i] < counts[best] { best=i; } }
    access[best]
}
fn do_hire(farm:&mut Farm, private:&mut Private, mult:i64) {
    let cost=hire_cost(farm.hires_today,mult);
    if farm.money < cost { return; }
    let spawn = spawn_hand(farm);
    farm.money -= cost;
    farm.hires_today += 1;
    farm.hands.push(Unit{pos:spawn});
    private.inventories.push(Inventory::new());
}
fn do_buy_land(farm:&mut Farm) {
    let extra=(farm.unlocked-1) as usize;
    if extra >= 3 { return; }
    let cost=[1000i64,2000,4000][extra];
    if farm.money < cost { return; }
    farm.money -= cost;
    farm.unlocked += 1;
    for y in 0..BOARD as i32 { for x in 0..BOARD as i32 {
        if quadrant(x,y) == (extra+1) as u8 && matches!(farm.tiles[tile_idx(x,y)],Tile::Locked) { farm.tiles[tile_idx(x,y)] = Tile::Empty; }
    }}
}

fn commit_market_unit(order:&MarketOrder, unit_price:i64, farm:&mut Farm, private:&mut Private, market:&mut Market, shed_cap:i32) -> bool {
    match *order {
        MarketOrder::Sell(item,_) => {
            if private.shed[item.idx()] <= 0 { return false; }
            private.shed[item.idx()] -= 1;
            farm.money += unit_price;
            if unit_price > 1 { market.inventory[item.idx()] += 1; }
            true
        }
        MarketOrder::BuyProduct(item,_) => {
            if farm.money < unit_price || shed_total(private) >= shed_cap { return false; }
            farm.money -= unit_price;
            private.shed[item.idx()] += 1;
            market.inventory[item.idx()] -= 1;
            true
        }
        MarketOrder::BuySeed(crop,_) => {
            if farm.money < unit_price { return false; }
            farm.money -= unit_price;
            private.seeds[crop as usize] += 1;
            true
        }
        MarketOrder::BuyAnimal(animal,_) => {
            if farm.money < unit_price || shed_total(private) >= shed_cap { return false; }
            farm.money -= unit_price;
            private.animals_in_shed[animal as usize] += 1;
            true
        }
        MarketOrder::Hire | MarketOrder::BuyLand | MarketOrder::Invalid => false,
    }
}

fn market_processing(game:&mut Game, actions:[&StepAction;2]) {
    let max_market_orders = game.cfg.max_market_orders;
    let hire_mult = game.cfg.farm_hand_cost_mult;
    let shed_cap = game.cfg.shed_capacity;
    let max_len = actions[0].market.len().min(max_market_orders).max(actions[1].market.len().min(max_market_orders));

    for slot in 0..max_len {
        let mut active:[Option<&MarketOrder>;2] = [None,None];
        for p in 0..2 {
            if slot < actions[p].market.len().min(max_market_orders) {
                active[p] = Some(&actions[p].market[slot]);
            }
        }

        // Atomic HIRE / BUY_LAND orders happen once, in player order.
        for p in 0..2 {
            match active[p] {
                Some(MarketOrder::Hire) => { do_hire(&mut game.farms[p],&mut game.privs[p],hire_mult); active[p]=None; }
                Some(MarketOrder::BuyLand) => { do_buy_land(&mut game.farms[p]); active[p]=None; }
                _ => {}
            }
        }

        let mut remaining=[0i32;2];
        let mut alive=[true;2];
        for p in 0..2 {
            remaining[p]=match active[p] {
                Some(MarketOrder::Sell(_,n))|Some(MarketOrder::BuyProduct(_,n))|Some(MarketOrder::BuySeed(_,n))|Some(MarketOrder::BuyAnimal(_,n)) => (*n).max(0),
                _=>0,
            };
        }

        // Each successful unit is quoted from the same pre-commit market
        // inventory for both seats, then both commits are applied in seat order.
        let mut guard=0usize;
        while guard < 100_000 {
            guard += 1;
            let mut quotes:[Option<(i64,&MarketOrder)>;2]=[None,None];
            for p in 0..2 {
                if !alive[p] || remaining[p] <= 0 { continue; }
                let Some(order)=active[p] else { continue; };
                let quote = match *order {
                    MarketOrder::Sell(item,_) => Some((market_price(item,game.market.inventory[item.idx()], &game.cfg.market_overrides),order)),
                    MarketOrder::BuyProduct(item,_) if matches!(item,Product::Wheat|Product::Fertilizer) => Some((market_price(item,game.market.inventory[item.idx()]-1, &game.cfg.market_overrides),order)),
                    MarketOrder::BuySeed(crop,_) => Some((crop_cfg(crop).seed,order)),
                    MarketOrder::BuyAnimal(animal,_) => Some((animal_cfg(animal).cost,order)),
                    _ => None,
                };
                if let Some(q)=quote { quotes[p]=Some(q); }
                else { alive[p]=false; remaining[p]=0; }
            }
            if quotes[0].is_none() && quotes[1].is_none() { break; }
            let mut committed=false;
            for p in 0..2 {
                if let Some((unit_price,order))=quotes[p] {
                    if commit_market_unit(order,unit_price,&mut game.farms[p],&mut game.privs[p],&mut game.market,shed_cap) {
                        remaining[p]-=1;
                        committed=true;
                    } else {
                        alive[p]=false;
                        remaining[p]=0;
                    }
                }
            }
            if !committed { break; }
        }
        refresh_prices(&mut game.market, &game.cfg.market_overrides);
    }
}

fn town_consume(game:&mut Game,step:usize) {
    if step % game.cfg.shop_sell_interval == 0 {
        for shop in game.town.shops.iter().copied() {
            let products=shop.products();
            let multiplier=if products.len()==1{2}else{1};
            for item in products { game.market.inventory[item.idx()] -= multiplier; }
        }
    }
    if step % game.cfg.center_sell_interval == 0 {
        for idx in 0..8 { game.market.inventory[idx] -= 1; }
    }
    refresh_prices(&mut game.market, &game.cfg.market_overrides);
}

fn decay_plants(farm:&mut Farm,step:usize) {
    for ti in 0..TILES {
        let Tile::Plant(mut plant)=farm.tiles[ti] else { continue; };
        if plant.max_lifespan_step < 0 || step as i32 < plant.max_lifespan_step { continue; }
        if (step as i32 - plant.max_lifespan_step) % 2 != 0 { continue; }
        plant.yield_units -= 1;
        farm.tiles[ti] = if plant.yield_units <= 0 { Tile::Weed } else { Tile::Plant(plant) };
    }
}

fn daily_refresh_plants(farm:&mut Farm, current_day:i32, turns_per_day:usize) {
    let next_day=current_day+1;
    for ti in 0..TILES {
        let Tile::Plant(mut plant)=farm.tiles[ti] else { continue; };
        let was_watered=plant.watered_today;
        if was_watered { plant.consecutive_unwatered=0; } else { plant.consecutive_unwatered+=1; }
        plant.watered_today=false;
        if plant.consecutive_unwatered >= 2 { farm.tiles[ti]=Tile::Weed; continue; }
        let c=crop_cfg(plant.crop);
        if !c.ongoing { farm.tiles[ti]=Tile::Plant(plant); continue; }
        let days_since_first=next_day-plant.planted_day-c.first;
        if days_since_first < 0 { farm.tiles[ti]=Tile::Plant(plant); continue; }
        if days_since_first % c.interval != 0 { farm.tiles[ti]=Tile::Plant(plant); continue; }
        let production_count=days_since_first/c.interval+1;
        if production_count > c.max_yield { farm.tiles[ti]=Tile::Plant(plant); continue; }
        let fertilized=was_watered && plant.fertilized_until_day >= current_day;
        plant.yield_units=(plant.yield_units + if fertilized{2}else{1}).min(c.max_yield);
        if production_count == c.max_yield { plant.max_lifespan_step=(next_day+1)*turns_per_day as i32; }
        farm.tiles[ti]=Tile::Plant(plant);
    }
}

fn daily_refresh_animals(farm:&mut Farm,day:i32) {
    let next_day=day+1;
    for ti in 0..TILES {
        let (kind,animal,mut state)=match farm.tiles[ti] {
            Tile::Coop{animal:Some(a),state:Some(s)}=>(Structure::Coop,a,s),
            Tile::Pasture{animal:Some(a),state:Some(s)}=>(Structure::Pasture,a,s),
            _=>continue,
        };
        if state.fed_today { state.consecutive_unfed=0; } else { state.consecutive_unfed+=1; }
        if state.consecutive_unfed >= 2 {
            farm.tiles[ti]=match kind { Structure::Coop=>Tile::Coop{animal:None,state:None}, Structure::Pasture=>Tile::Pasture{animal:None,state:None} };
            continue;
        }
        let a=animal_cfg(animal);
        let days_since_first=next_day-state.placed_day-a.first;
        if days_since_first >= 0 && days_since_first % a.interval == 0 {
            let bonus=if state.fed_today{state.pending_care_bonus}else{0};
            state.yield_units=(state.yield_units+1+bonus).min(a.max_held);
            state.pending_care_bonus=0;
        }
        if state.cared_today && state.fed_today { state.pending_care_bonus += 1; }
        state.fertilizer_available=true;
        state.fed_today=false;
        state.cared_today=false;
        farm.tiles[ti]=match kind { Structure::Coop=>Tile::Coop{animal:Some(animal),state:Some(state)}, Structure::Pasture=>Tile::Pasture{animal:Some(animal),state:Some(state)} };
    }
}

fn spawn_weeds(farm:&mut Farm,rng:&mut PythonRandom,chance:f64) {
    for ti in 0..TILES {
        if matches!(farm.tiles[ti],Tile::Empty) && rng.random() < chance { farm.tiles[ti]=Tile::Weed; }
    }
}

fn drop_inventories_to_shed(private:&mut Private, shed_cap:i32) {
    let mut room=(shed_cap-shed_total(private)).max(0);
    for inv_index in 0..private.inventories.len() {
        let keys=private.inventories[inv_index].keys.clone();
        for key in keys {
            let id=key.0;
            let n=private.inventories[inv_index].counts[id];
            if n<=0 { continue; }
            let take=n.min(room);
            if take>0 {
                if id<PRODUCT_COUNT { private.shed[id]+=take; } else { private.animals_in_shed[id-PRODUCT_COUNT]+=take; }
                room-=take;
            }
            private.inventories[inv_index].counts[id]=0;
        }
        private.inventories[inv_index].keys.clear();
    }
}

fn end_of_day(game:&mut Game,day:i32,seed:i64) {
    let turns_per_day=game.cfg.turns_per_day;
    let weed_chance=game.cfg.weed_spawn_chance;
    let shed_cap=game.cfg.shed_capacity;
    let shop_unlock_interval=game.cfg.shop_unlock_interval;
    let rng_seed_i128=(seed as i128) * 1_000_003i128 ^ (day as i128);
    let mut rng=PythonRandom::seeded_int(rng_seed_i128);
    for p in 0..2 {
        daily_refresh_plants(&mut game.farms[p],day,turns_per_day);
        daily_refresh_animals(&mut game.farms[p],day);
        spawn_weeds(&mut game.farms[p],&mut rng,weed_chance);
        drop_inventories_to_shed(&mut game.privs[p],shed_cap);
        game.farms[p].farmer=default_spawn();
        game.farms[p].hands.clear();
        game.farms[p].hires_today=0;
        game.privs[p].inventories.truncate(1);
        game.privs[p].inventories[0]=Inventory::new();
    }
    let next_day=(day+1) as usize;
    if next_day>0 && next_day % shop_unlock_interval == 0 && game.town.shops.len() < MAX_SHOPS { game.town.shops.push(Shop::from_sorted_index(rng.choice8())); }
}

fn tape_step<'a>(steps:&'a [StepAction], step:usize, empty:&'a StepAction) -> &'a StepAction {
    if let Some(x) = steps.get(step) { x }
    else if let Some(x) = steps.last() { x }
    else { empty }
}

pub fn simulate(seed:i64,a:&Tape,b:&Tape,saved_states:usize,cfg:SimConfig,trim_hands:bool,a_seat:usize,b_seat:usize)->Result<[i64;2],SimError> {
    if saved_states == 0 { return Err(SimError("steps must be >= 1".into())); }
    if cfg.turns_per_day == 0 || cfg.max_market_orders == 0 || cfg.shop_sell_interval == 0 || cfg.center_sell_interval == 0 || cfg.shop_unlock_interval == 0 {
        return Err(SimError("invalid zero interval in configuration".into()));
    }
    let mut game = new_game(cfg);
    refresh_prices(&mut game.market, &game.cfg.market_overrides);
    let turns_per_day = game.cfg.turns_per_day;
    let shed_cap = game.cfg.shed_capacity;
    // Environment.run saves the initial state as state 0. Thus 720 saved states
    // contain exactly 719 action turns.
    let action_turns = saved_states.saturating_sub(1);
    for step in 0..action_turns {
        let day = (step / turns_per_day) as i32;
        let empty = StepAction::default();
        let a_step = tape_step(a.seat(a_seat), step, &empty);
        let b_step = tape_step(b.seat(b_seat), step, &empty);
        let acts = [a_step, b_step];

        for p in 0..2 {
            // The real tape agent can trim helper slots to the currently live
            // helper count. Without trimming, stale helper slots still count
            // toward the atomic PLANT seed-demand check.
            let live_hands = game.farms[p].hands.len();
            let hand_count = if trim_hands { acts[p].hands.len().min(live_hands) } else { acts[p].hands.len() };

            let mut demand = [0i32; CROP_COUNT];
            if let UnitAction::Plant(crop) = &acts[p].farmer { demand[*crop as usize] += 1; }
            for action in acts[p].hands.iter().take(hand_count) {
                if let UnitAction::Plant(crop) = action { demand[*crop as usize] += 1; }
            }
            let seeds = game.privs[p].seeds;
            let mut blocked = [false; CROP_COUNT];
            for i in 0..CROP_COUNT { blocked[i] = demand[i] > seeds[i]; }

            let farmer_action = match &acts[p].farmer {
                UnitAction::Plant(c) if blocked[*c as usize] => UnitAction::Pass,
                other => other.clone(),
            };
            do_unit_action(&mut game.farms[p], &mut game.privs[p], 0, &farmer_action, day, turns_per_day, shed_cap);
            for (idx, action) in acts[p].hands.iter().take(hand_count).enumerate() {
                let filtered = match action {
                    UnitAction::Plant(c) if blocked[*c as usize] => UnitAction::Pass,
                    other => other.clone(),
                };
                do_unit_action(&mut game.farms[p], &mut game.privs[p], idx + 1, &filtered, day, turns_per_day, shed_cap);
            }
        }

        market_processing(&mut game, [a_step, b_step]);
        town_consume(&mut game, step);
        for farm in &mut game.farms { decay_plants(farm, step); }
        if (step + 1) % turns_per_day == 0 { end_of_day(&mut game, day, seed); }
    }
    Ok([game.farms[0].money, game.farms[1].money])
}
