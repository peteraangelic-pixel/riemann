use crate::model::*;
use serde_json::Value;
use std::{fs, path::Path};

fn int_arg(v:&Value,i:usize)->Option<i32>{
    v.as_array()?.get(i)?.as_i64().and_then(|x| i32::try_from(x).ok())
}
fn str_arg(v:&Value,i:usize)->Option<&str>{v.as_array()?.get(i)?.as_str()}

pub fn parse_unit(v:&Value)->UnitAction{
    let Some(a)=v.as_array() else{return UnitAction::Pass};
    let Some(op)=a.first().and_then(Value::as_str) else{return UnitAction::Pass};
    match op {
        "NORTH"=>UnitAction::North,"SOUTH"=>UnitAction::South,"EAST"=>UnitAction::East,"WEST"=>UnitAction::West,"PASS"=>UnitAction::Pass,
        "DROP"=>UnitAction::Drop,
        "PICKUP"=>{
            let n=if a.len()>=3{match int_arg(v,2){Some(n)=>n,None=>return UnitAction::Pass}}else{1};
            if n<=0{return UnitAction::Pass;}
            let Some(s)=str_arg(v,1) else{return UnitAction::Pass};
            Product::from_str(s).map(|p|UnitAction::PickupProduct(p,n)).or_else(||Animal::from_str(s).map(|x|UnitAction::PickupAnimal(x,n))).unwrap_or(UnitAction::Pass)
        }
        "PLANT"=>str_arg(v,1).and_then(Crop::from_str).map(UnitAction::Plant).unwrap_or(UnitAction::Pass),
        "WATER"=>UnitAction::Water,"HARVEST"=>UnitAction::Harvest,"FERTILIZE"=>UnitAction::Fertilize,
        "BUILD_COOP"=>UnitAction::BuildCoop,"BUILD_PASTURE"=>UnitAction::BuildPasture,"DIG"=>UnitAction::Dig,
        "PLACE"=>{ let Some(s)=str_arg(v,1) else { return UnitAction::Pass; }; let n=if a.len()>=3{match int_arg(v,2){Some(n) if n>0=>n,_=>return UnitAction::Pass}}else{1}; if let Some(x)=Animal::from_str(s) { UnitAction::PlaceAnimal(x,n) } else if let Some(p)=Product::from_str(s) { UnitAction::PlaceProduct(p,n) } else { UnitAction::Pass } },
        "FEED"=>UnitAction::Feed,"COLLECT_FERTILIZER"=>UnitAction::CollectFertilizer,"CARE"=>UnitAction::Care,
        _=>UnitAction::Pass,
    }
}

pub fn parse_market(v:&Value)->MarketOrder{
    let Some(a)=v.as_array() else{return MarketOrder::Invalid};
    let Some(op)=a.first().and_then(Value::as_str) else{return MarketOrder::Invalid};
    match op {
        "HIRE"=>MarketOrder::Hire,
        "BUY_LAND"=>MarketOrder::BuyLand,
        "BUY_SEED"=>match(a.get(1).and_then(Value::as_str).and_then(Crop::from_str),int_arg(v,2)){(Some(c),Some(n)) if n>0=>MarketOrder::BuySeed(c,n),_=>MarketOrder::Invalid},
        "BUY_PRODUCT"=>match(a.get(1).and_then(Value::as_str).and_then(Product::from_str),int_arg(v,2)){(Some(p),Some(n)) if n>0=>MarketOrder::BuyProduct(p,n),_=>MarketOrder::Invalid},
        "BUY_ANIMAL"=>match(a.get(1).and_then(Value::as_str).and_then(Animal::from_str),int_arg(v,2)){(Some(x),Some(n)) if n>0=>MarketOrder::BuyAnimal(x,n),_=>MarketOrder::Invalid},
        "SELL"=>match(a.get(1).and_then(Value::as_str).and_then(Product::from_str),int_arg(v,2)){(Some(p),Some(n)) if n>0=>MarketOrder::Sell(p,n),_=>MarketOrder::Invalid},
        _=>MarketOrder::Invalid,
    }
}

pub fn parse_step(v:&Value)->StepAction{
    let Some(obj)=v.as_object() else{return StepAction::default()};
    let farmer=obj.get("farmer").map(parse_unit).unwrap_or_default();
    let hands=obj.get("hands").and_then(Value::as_array).map(|a|a.iter().map(parse_unit).collect()).unwrap_or_default();
    let market=obj.get("market").and_then(Value::as_array).map(|a|a.iter().map(parse_market).collect()).unwrap_or_default();
    StepAction{farmer,hands,market}
}

pub fn load_tape(path:&Path)->Result<Tape,String>{
    let bytes=fs::read(path).map_err(|e|format!("{}: {e}",path.display()))?;
    let root:Value=serde_json::from_slice(&bytes).map_err(|e|format!("{}: {e}",path.display()))?;
    let Value::Array(root_array)=root else { return Err("tape root must be [seat][step] or [step] JSON".into()); };
    if root_array.is_empty() { return Err("tape must not be empty".into()); }

    // Canonical form is [seat][step]. Keep both seat-specific action streams.
    if root_array.first().is_some_and(Value::is_array) {
        if root_array.len() < 2 { return Err("[seat][step] tape must contain two seat lists".into()); }
        let seat0=root_array[0].as_array().ok_or("seat 0 must be an array")?;
        let seat1=root_array[1].as_array().ok_or("seat 1 must be an array")?;
        if seat0.is_empty() || seat1.is_empty() { return Err("both seat lists must be non-empty".into()); }
        return Ok(Tape{seats:[seat0.iter().map(parse_step).collect(),seat1.iter().map(parse_step).collect()]});
    }

    // Convenience form: [step] means the same policy stream for either seat.
    let steps=root_array.iter().map(parse_step).collect::<Vec<_>>();
    if steps.is_empty() { return Err("tape must contain at least one step".into()); }
    Ok(Tape{seats:[steps.clone(),steps]})
}
