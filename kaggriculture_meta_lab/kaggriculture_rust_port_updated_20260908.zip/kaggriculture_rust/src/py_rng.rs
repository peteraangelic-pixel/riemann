#[derive(Clone, Debug)]
pub struct PythonRandom { mt:[u32;624], index:usize }
impl PythonRandom {
    pub fn seeded(seed:i64)->Self { Self::seeded_int(seed as i128) }
    pub fn seeded_int(seed:i128)->Self {
        let mut n = if seed < 0 { -seed } else { seed };
        let mut key = Vec::<u32>::new();
        let mut x=n as u128;
        if x==0 { key.push(0); } else { while x>0 { key.push((x & 0xffff_ffff) as u32); x >>= 32; } }
        let mut r=Self{mt:[0;624],index:624};
        r.init_genrand(19650218);
        let mut i=1usize; let mut j=0usize; let mut k=624usize.max(key.len());
        while k>0 {
            r.mt[i]=(r.mt[i] ^ ((r.mt[i-1] ^ (r.mt[i-1]>>30)).wrapping_mul(1664525))).wrapping_add(key[j]).wrapping_add(j as u32);
            i+=1;j+=1;
            if i>=624{r.mt[0]=r.mt[623];i=1;}
            if j>=key.len(){j=0;}
            k-=1;
        }
        k=623;
        while k>0 {
            r.mt[i]=(r.mt[i] ^ ((r.mt[i-1] ^ (r.mt[i-1]>>30)).wrapping_mul(1566083941))).wrapping_sub(i as u32);
            i+=1;
            if i>=624{r.mt[0]=r.mt[623];i=1;}
            k-=1;
        }
        r.mt[0]=0x80000000; r.index=624; r
    }
    fn init_genrand(&mut self, s:u32){
        self.mt[0]=s;
        for i in 1..624 { self.mt[i]=1812433253u32.wrapping_mul(self.mt[i-1] ^ (self.mt[i-1]>>30)).wrapping_add(i as u32); }
        self.index=624;
    }
    fn twist(&mut self){for i in 0..624{let y=(self.mt[i]&0x80000000)|(self.mt[(i+1)%624]&0x7fffffff);let mut v=self.mt[(i+397)%624]^(y>>1);if y&1!=0{v^=0x9908b0df;}self.mt[i]=v;}self.index=0;}
    pub fn u32(&mut self)->u32{if self.index>=624{self.twist();}let mut y=self.mt[self.index];self.index+=1;y^=y>>11;y^=(y<<7)&0x9d2c5680;y^=(y<<15)&0xefc60000;y^=y>>18;y}
    pub fn random(&mut self)->f64{let a=(self.u32()>>5) as u64;let b=(self.u32()>>6) as u64;((a<<26)|b) as f64 / 9007199254740992.0}
    pub fn getrandbits(&mut self,k:u32)->u32{assert!(k>0&&k<=32);self.u32()>>(32-k)}
    pub fn randbelow(&mut self,n:usize)->usize{assert!(n>0);let k=n.leading_zeros();let k=(usize::BITS-k) as u32;loop{let r=self.getrandbits(k);if (r as usize)<n{return r as usize;}}}
    pub fn choice8(&mut self)->usize{self.randbelow(8)}
}
