mod model;
mod py_rng;
mod sim;
mod tape;

use clap::Parser;
use rayon::prelude::*;
use serde_json::json;
use std::{
    collections::HashMap,
    fs,
    path::{Path, PathBuf},
    process::ExitCode,
    sync::Arc,
};

#[derive(Debug, Parser)]
#[command(name = "kg_sim", version, about = "Fast Kaggriculture tape replay simulator")]
struct Args {
    #[arg(long)]
    tape_a: Option<PathBuf>,
    #[arg(long)]
    tape_b: Option<PathBuf>,
    #[arg(long, allow_hyphen_values = true)]
    seed: Option<i128>,
    /// Number of saved Kaggle states. The initial state is state 0, so 720 means 719 action turns.
    #[arg(long, default_value_t = 720)]
    steps: usize,
    /// Explicit number of action turns. Mutually exclusive in intent with --steps; when supplied it wins.
    #[arg(long)]
    turns: Option<usize>,
    #[arg(long, default_value_t = false)]
    reverse_seats: bool,
    /// Replay tape hands only for helpers that are actually alive. Without this flag, all tape hand slots participate.
    #[arg(long, default_value_t = false)]
    trim_hands: bool,
    #[arg(long)]
    jobs: Option<PathBuf>,
    #[arg(long)]
    config: Option<PathBuf>,
    /// Override Rayon worker count. Otherwise RAYON_NUM_THREADS / Rayon defaults apply.
    #[arg(long)]
    threads: Option<usize>,
}

fn error_json(message: impl Into<String>) -> serde_json::Value {
    json!({"rewards":null,"errors":[message.into()]})
}

fn run_loaded(
    seed: i64,
    tape_a: &tape::Tape,
    tape_b: &tape::Tape,
    saved_states: usize,
    reverse: bool,
    trim_hands: bool,
    cfg: model::SimConfig,
) -> serde_json::Value {
    let result = if reverse {
        sim::simulate(seed, tape_a, tape_b, saved_states, cfg.clone(), trim_hands, 1, 0)
    } else {
        sim::simulate(seed, tape_a, tape_b, saved_states, cfg.clone(), trim_hands, 0, 1)
    };
    match result {
        Ok(r) => {
            let rewards = if reverse { vec![r[1], r[0]] } else { vec![r[0], r[1]] };
            json!({"rewards":rewards,"errors":[]})
        }
        Err(e) => error_json(e.to_string()),
    }
}

fn checked_i128_to_i64(seed: i128) -> Result<i64, String> {
    i64::try_from(seed).map_err(|_| format!("seed {seed} is outside signed 64-bit range"))
}

fn run_one(
    seed: i128,
    tape_a: &Path,
    tape_b: &Path,
    saved_states: usize,
    reverse: bool,
    trim_hands: bool,
    cfg: model::SimConfig,
) -> serde_json::Value {
    let seed = match checked_i128_to_i64(seed) {
        Ok(v) => v,
        Err(e) => return error_json(e),
    };
    let a = match tape::load_tape(tape_a) {
        Ok(v) => v,
        Err(e) => return error_json(format!("tape_a: {e}")),
    };
    let b = match tape::load_tape(tape_b) {
        Ok(v) => v,
        Err(e) => return error_json(format!("tape_b: {e}")),
    };
    run_loaded(seed, &a, &b, saved_states, reverse, trim_hands, cfg)
}

fn parse_reverse(s: &str) -> bool {
    matches!(
        s.trim().to_ascii_lowercase().as_str(),
        "1" | "true" | "yes" | "y" | "reverse"
    )
}

#[derive(Clone)]
struct Job {
    input_index: usize,
    seed: Option<i128>,
    tape_a: PathBuf,
    tape_b: PathBuf,
    reverse: bool,
    parse_error: Option<String>,
}

fn resolve_job_path(csv_path: &Path, raw: &str) -> PathBuf {
    let p = PathBuf::from(raw);
    if p.is_absolute() { p } else { csv_path.parent().unwrap_or(Path::new(".")).join(p) }
}

fn load_tape_cache(jobs: &[Job]) -> HashMap<PathBuf, Result<Arc<tape::Tape>, String>> {
    let mut unique = HashMap::<PathBuf, ()>::new();
    for job in jobs {
        if !job.tape_a.as_os_str().is_empty() { unique.entry(job.tape_a.clone()).or_insert(()); }
        if !job.tape_b.as_os_str().is_empty() { unique.entry(job.tape_b.clone()).or_insert(()); }
    }
    let mut cache = HashMap::with_capacity(unique.len());
    for path in unique.into_keys() {
        let value = tape::load_tape(&path)
            .map(Arc::new)
            .map_err(|e| format!("{}: {e}", path.display()));
        cache.insert(path, value);
    }
    cache
}

fn market_func_code(s: &str) -> Option<u8> {
    match s {
        "linear" => Some(1), "sq" => Some(6), "sqrt" => Some(2),
        "log" => Some(3), "log10" => Some(4), "hinge" => Some(5), _ => None,
    }
}

fn product_index(name: &str) -> Option<usize> {
    match name {
        "WHEAT" => Some(0), "CARROT" => Some(1), "TOMATO" => Some(2),
        "STRAWBERRY" => Some(3), "MELON" => Some(4), "EGG" => Some(5),
        "MILK" => Some(6), "WOOL" => Some(7), "FERTILIZER" => Some(8), _ => None,
    }
}

fn load_config(path: Option<&PathBuf>) -> Result<model::SimConfig, String> {
    let Some(path) = path else { return Ok(model::SimConfig::default()); };
    let text = fs::read_to_string(path).map_err(|e| format!("{}: {e}", path.display()))?;
    let root: serde_json::Value = serde_json::from_str(&text).map_err(|e| format!("{}: {e}", path.display()))?;
    let c = root.get("configuration").unwrap_or(&root);
    let d = model::SimConfig::default();
    let get_u = |k:&str, def:usize| c.get(k).and_then(serde_json::Value::as_u64).map(|x| x as usize).unwrap_or(def);
    let get_i = |k:&str, def:i64| c.get(k).and_then(serde_json::Value::as_i64).unwrap_or(def);
    let get_f = |k:&str, def:f64| c.get(k).and_then(serde_json::Value::as_f64).unwrap_or(def);
    let board_size = c.get("boardSize").and_then(serde_json::Value::as_u64).unwrap_or(10) as usize;
    if board_size != 10 {
        return Err(format!("this optimized fixed-array port requires boardSize=10 (config requested {board_size})"));
    }

    let mut overrides = [None; model::PRODUCT_COUNT];
    if let Some(mp) = c.get("marketParams").and_then(serde_json::Value::as_object) {
        for (name, patch) in mp {
            let Some(idx) = product_index(name) else { continue; };
            let Some(obj) = patch.as_object() else { continue; };
            let mut ov = model::MarketOverride { base:None, i0:None, t:None, below_func:None, below_target:None, above_func:None, above_target:None };
            if let Some(v)=obj.get("base").and_then(serde_json::Value::as_i64){ov.base=Some(v);}
            if let Some(v)=obj.get("I0").and_then(serde_json::Value::as_i64){ov.i0=i32::try_from(v).ok();}
            if let Some(v)=obj.get("T").and_then(serde_json::Value::as_i64){ov.t=i32::try_from(v).ok();}
            if let Some(v)=obj.get("below_func").and_then(serde_json::Value::as_str){ov.below_func=market_func_code(v);}
            if let Some(v)=obj.get("below_target").and_then(serde_json::Value::as_f64){ov.below_target=Some(v);}
            if let Some(v)=obj.get("above_func").and_then(serde_json::Value::as_str){ov.above_func=market_func_code(v);}
            if let Some(v)=obj.get("above_target").and_then(serde_json::Value::as_f64){ov.above_target=Some(v);}
            overrides[idx]=Some(ov);
        }
    }

    Ok(model::SimConfig {
        starting_money:get_i("startingMoney",d.starting_money), turns_per_day:get_u("turnsPerDay",d.turns_per_day),
        shed_capacity:get_i("shedCapacity",d.shed_capacity) as i32, max_market_orders:get_u("maxMarketOrdersPerTurn",d.max_market_orders),
        weed_spawn_chance:get_f("weedSpawnChance",d.weed_spawn_chance), shop_unlock_interval:get_u("townShopUnlockInterval",d.shop_unlock_interval),
        shop_sell_interval:get_u("townShopSellInterval",d.shop_sell_interval), center_sell_interval:get_u("townCenterSellInterval",d.center_sell_interval),
        farm_hand_cost_mult:get_i("farmHandCostMult",d.farm_hand_cost_mult), market_overrides:overrides,
    })
}

fn parse_jobs(content:&str, csv_path:&Path) -> Vec<Job> {
    let mut jobs=Vec::new();
    for (idx,raw) in content.lines().enumerate() {
        let line=raw.trim();
        if line.is_empty() || line.starts_with('#') { continue; }
        let parts:Vec<&str>=line.split(',').map(str::trim).collect();
        if parts.first().is_some_and(|s| s.eq_ignore_ascii_case("seed")) { continue; }
        if parts.len()<3 {
            jobs.push(Job{input_index:idx,seed:None,tape_a:PathBuf::new(),tape_b:PathBuf::new(),reverse:false,parse_error:Some("jobs row needs seed,tape_a,tape_b[,reverse]".into())});
            continue;
        }
        let seed=match parts[0].parse::<i128>() { Ok(v)=>Some(v), Err(_)=>None };
        let parse_error = if seed.is_none() { Some(format!("invalid seed: {}",parts[0])) } else { None };
        jobs.push(Job{input_index:idx,seed,tape_a:resolve_job_path(csv_path,parts[1]),tape_b:resolve_job_path(csv_path,parts[2]),reverse:parts.get(3).is_some_and(|s|parse_reverse(s)),parse_error});
    }
    jobs
}

fn main() -> ExitCode {
    let args=Args::parse();
    let cfg=match load_config(args.config.as_ref()) { Ok(c)=>c, Err(e)=>{eprintln!("invalid config: {e}");return ExitCode::from(2);} };
    let saved_states=match args.turns { Some(t)=>t.saturating_add(1), None=>args.steps };
    if let Some(n)=args.threads {
        if n==0 { eprintln!("--threads must be >= 1"); return ExitCode::from(2); }
        if let Err(e)=rayon::ThreadPoolBuilder::new().num_threads(n).build_global() { eprintln!("failed to configure Rayon: {e}"); return ExitCode::from(2); }
    }

    if let Some(jobs_path)=args.jobs {
        let content=match fs::read_to_string(&jobs_path){Ok(x)=>x,Err(e)=>{eprintln!("failed to read jobs file {}: {e}",jobs_path.display());return ExitCode::from(2);}};
        let jobs=parse_jobs(&content,&jobs_path);
        let cache=load_tape_cache(&jobs);
        let had_error=std::sync::atomic::AtomicBool::new(false);
        let mut output:Vec<(usize,String)>=jobs.par_iter().map(|job|{
            let value=if let Some(err)=&job.parse_error { error_json(err) }
            else {
                let seed=job.seed.expect("parse_error guarantees seed");
                match (cache.get(&job.tape_a),cache.get(&job.tape_b)) {
                    (Some(Ok(a)),Some(Ok(b))) => {
                        let seed64=match checked_i128_to_i64(seed){Ok(v)=>v,Err(e)=>error_json(e)};
                        match seed64 { Ok(s)=>run_loaded(s,a,b,saved_states,job.reverse,args.trim_hands,cfg.clone()), Err(v)=>v }
                    }
                    (Some(Err(e)),_)=>error_json(e),
                    (_,Some(Err(e)))=>error_json(e),
                    _=>error_json("tape missing from preloaded cache"),
                }
            };
            if value.get("errors").and_then(|v|v.as_array()).is_some_and(|a|!a.is_empty()) { had_error.store(true,std::sync::atomic::Ordering::Relaxed); }
            (job.input_index,serde_json::to_string(&value).unwrap_or_else(|_|r#"{"rewards":null,"errors":["serialization error"]}"#.to_string()))
        }).collect();
        output.par_sort_unstable_by_key(|x|x.0);
        for (_,line) in output { println!("{line}"); }
        return if had_error.load(std::sync::atomic::Ordering::Relaxed) { ExitCode::from(1) } else { ExitCode::SUCCESS };
    }

    let (Some(a),Some(b),Some(seed))=(args.tape_a,args.tape_b,args.seed) else {
        eprintln!("usage: kg_sim --tape-a <a.json> --tape-b <b.json> --seed <int> --steps 720 [--reverse-seats] [--trim-hands]");
        return ExitCode::from(2);
    };
    let value=run_one(seed,&a,&b,saved_states,args.reverse_seats,args.trim_hands,cfg);
    println!("{}",serde_json::to_string(&value).expect("JSON serialization cannot fail"));
    if value.get("errors").and_then(|v|v.as_array()).is_some_and(|a|!a.is_empty()) { ExitCode::from(1) } else { ExitCode::SUCCESS }
}
