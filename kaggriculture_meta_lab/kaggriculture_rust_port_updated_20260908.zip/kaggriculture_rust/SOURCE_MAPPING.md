# Port mapping — authoritative Python source

This Rust implementation was rebuilt against the user-supplied `kaggriculture_sim.py` pasted in chat on 2026-09-07.

| Python | Rust |
|---|---|
| `CROPS`, `ANIMALS`, `PRODUCTS` | `crop_cfg`, `animal_cfg`, enum IDs |
| `_shape`, `market_price`, `_refresh_prices` | `shape`, `market_price`, `refresh_prices` |
| `_new_farm`, `_new_private`, `_new_market`, `_new_town` | `new_farm`, `Private::new`, `new_market`, `Town` |
| `_apply_unit_action` | `do_unit_action` |
| `_process_market` | `market_processing` |
| `_commit_unit` | `commit_market_unit` |
| `_do_hire`, `_do_buy_land` | `do_hire`, `do_buy_land` |
| `_town_consume` | `town_consume` |
| `_decay_plants` | `decay_plants` |
| `_daily_refresh_plants` | `daily_refresh_plants` |
| `_daily_refresh_animals` | `daily_refresh_animals` |
| `_spawn_weeds` | `spawn_weeds` |
| `_drop_inventories_to_shed` | `drop_inventories_to_shed` |
| `_end_of_day` | `end_of_day` |
| `interpreter` | `simulate` |

The web/UI renderers and demo agents are intentionally not ported; v1 replays decoded action tapes only, matching the handoff contract.
