# Validation notes

This archive was audited against the latest Python/handoff text supplied in chat.

## Checks performed here

- Python translation of the Rust MT19937 initialization and tempering was compared with CPython `random.Random` for multiple signed 64-bit seeds, including `0`, `1`, `-1`, `2**32`, `-2**63`, and `2**63-1`.
- CPython-compatible `randbelow(8)` behavior was checked against `random.randrange(8)` after fixing the bit-length/rejection implementation.
- Rust source files have balanced braces/parentheses.
- The supplied Python parity helper remains syntactically valid.

## Not performed here

This environment has no Rust compiler toolchain. Therefore `cargo build`, `cargo fmt`, `cargo clippy`, and a true Rust-vs-Kaggle byte-for-byte replay suite cannot be executed here.

The proper final acceptance test remains:

1. build with `cargo build --release`;
2. compare the Rust simulator to the real `kaggle-environments==1.32.7` simulator using asymmetric two-seat tapes;
3. test 719-action / 720-state behavior;
4. test `--reverse-seats` and `--trim-hands`;
5. test seed edge cases including `-2**63` and `2**63-1`;
6. run identical jobs with 1/2/4/16 Rayon threads and require identical outputs;
7. compare per-turn snapshots, not only final rewards.
