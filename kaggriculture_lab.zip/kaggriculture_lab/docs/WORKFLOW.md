# Workflow and interpretation

## Why replay analysis is still valuable

A public replay gives you a detailed, observable action trace. You can measure when an agent buys land, hires help, harvests, sells, builds infrastructure, and how its inventory/bank evolves. This can reveal strategy families and mutations that are invisible from leaderboard rating alone.

## Why a replay is not a full opponent

Suppose your candidate changes turn 100. The recorded opponent's turn 101 action was chosen in the old match state. When replayed against your changed candidate, that action does not recompute its private reasoning. This makes replay benchmarks open-loop.

Therefore:

- Use replay benchmarks for regression and adversarial screening.
- Use executable policy-vs-policy games for adaptive win-rate estimation.
- Use both for different questions.

## A useful experiment protocol

For each candidate mutation:

- Smoke: 20-50 games per opponent.
- Screen: 200-500 games, both seats.
- Confirmation: 2,000-10,000 games against a fixed pool.
- Submission: only after the mutation is stable against the pool.

Track:

- win / loss / tie;
- mean final-score margin;
- median margin;
- worst-decile margin;
- first divergence turn when comparing two deterministic policies;
- results by seat;
- results by seed block.

A strategy that wins 53% but has a stable positive margin across both seats and all seed blocks is generally more interesting than a strategy that wins 80% of a tiny sample with a few huge outliers.
