# Kaggriculture Lab

Local research harness for Kaggle's **Kaggriculture** simulation: replay archive ingestion, replay fingerprinting, open-loop benchmark analysis, and high-throughput executable-agent tournaments.

## Important distinction

This lab has two evaluation modes:

1. **Replay/open-loop analysis** — compare your candidate against the *recorded actions* of a public replay. This is reproducible and excellent for regression screening, but the recorded opponent does not react to changes in your state.
2. **Executable-agent league** — run two actual Python agents against each other locally using `kaggle-environments`. This is the mode to use for true adaptive win-rate estimation. You need runnable opponent policy files; a replay alone is not the opponent's source code.

Kaggle's official Kaggriculture docs confirm that the environment can run locally with Python callables or `.py` agent files, and that replay JSON can be dumped with `env.toJSON()`. The environment defaults to 720 turns. See `docs/WORKFLOW.md` for the practical workflow used here.

## Recommended environment

Use **Python 3.12**. The current public reproducibility reference used by one active Kaggriculture research repo is Python 3.12 with `kaggle-environments==1.32.4`.

With `uv`:

```powershell
uv venv --python 3.12
uv sync --extra dev
```

Or standard venv:

```powershell
py -3.12 -m venv .venv
.venv\\Scripts\\activate
python -m pip install -U pip
pip install -r requirements.txt
```

## 1) Download the public TOP replay archive

```powershell
python scripts/download_top.py --dataset-slug nnmax/kaggriculture-top10-replay-archive
```

The script downloads via the Kaggle CLI, extracts the archive, inventories all JSON/replay files and records a manifest. It never overwrites existing files unless `--force` is supplied.

If the dataset slug has changed, copy the current slug from Kaggle and pass it with `--dataset-slug`.

## 2) Inspect replay files

```powershell
python scripts/replay_inventory.py
python scripts/fingerprint.py --input data/replays --output artifacts/replay_fingerprints.csv
```

The fingerprinter intentionally uses observable action traces and tolerant JSON discovery. It reports early-action signatures, action frequencies, market timing, movement/production patterns and a compact hash. It is a screening tool, not a perfect semantic strategy classifier.

## 3) X-ray a single replay

```powershell
python scripts/xray.py path\\to\\replay.json --player 0
```

This produces a turn-by-turn summary, checkpoints, action counts and economy snapshots where the replay contains the corresponding fields.

## 4) Run an actual local league

Put runnable agent files in `agents/`, each exposing the normal Kaggriculture `agent(obs)` function. Then:

```powershell
python scripts/run_league.py ^
  --candidate agents/my_agent.py ^
  --opponent starter=starter ^
  --opponent random=random ^
  --games 1000 ^
  --workers 32 ^
  --swap-seats
```

Use multiple `--opponent` flags. `starter` and `random` are built-in Kaggle environment agents. For a Python file, use an absolute path or a path relative to the repository.

Results are written to `reports/league_*.json` and `.csv`.

### About seeds

The Kaggriculture interpreter records a resolved episode seed in `env.info["seed"]`. The harness supplies a deterministic configuration seed for every game. If your installed engine behaves differently, the runner logs the actual resolved seed so a result can be reproduced.

## 5) Candidate-vs-baseline experiment loop

```text
edit agent
  -> 200-1000 local games against a fixed opponent pool
  -> inspect win-rate AND paired score margin
  -> keep/reject mutation
  -> 5000+ confirmation games
  -> only then submit to Kaggle
```

Do not optimize only to one public replay. A replay is a fixed trace; an opponent policy is adaptive.

## 6) 5950X settings

Your Ryzen 9 5950X has 16 physical cores / 32 logical threads. Start with **16 worker processes**, benchmark, then try 24 and 32. More processes are not guaranteed to be faster because each Kaggriculture episode is Python-heavy and memory/cache pressure matters.

The runner uses processes rather than Python threads, so Python GIL contention is not the bottleneck.

## 7) What to build next

The useful end-state is:

```text
public replay archive
        |
        +--> fingerprints / clusters
        |
        +--> open-loop regression corpus
        |
        +--> selected public agent source files
                  |
                  v
          executable round-robin
                  |
                  v
       win-rate + paired margins
                  |
                  v
            candidate search
                  |
                  v
              Kaggle
```

### Legal / provenance hygiene

Keep public replay/code sources and attribution in `data/provenance.csv`. Do not commit Kaggle credentials or redistribute authenticated competition files. The active public research repo notes that its authenticated competition downloads, server logs and replays are intentionally kept out of Git because competition rules restrict redistribution.
