def agent(obs):
    # Deliberately trivial baseline for testing the harness.
    return {"farmer": ["PASS"], "hands": [], "market": []}
