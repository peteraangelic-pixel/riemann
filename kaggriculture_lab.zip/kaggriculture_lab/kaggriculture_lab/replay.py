from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, asdict
from typing import Any
import hashlib
import json
import re


@dataclass
class ReplaySummary:
    path: str
    episode_id: str | None
    steps: int
    players: int
    final_rewards: list[float | None]
    action_counts: dict[int, dict[str, int]]
    early_signature: str
    action_hash: str
    seat0_first_actions: list[str]
    seat1_first_actions: list[str]


def _find_steps(obj: Any):
    if isinstance(obj, dict):
        steps = obj.get("steps")
        if isinstance(steps, list) and steps and all(isinstance(x, list) for x in steps[: min(3, len(steps))]):
            return steps
        for v in obj.values():
            found = _find_steps(v)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for v in obj[:20]:
            found = _find_steps(v)
            if found is not None:
                return found
    return None


def _norm_action(action: Any) -> str:
    if action is None:
        return "<NONE>"
    if isinstance(action, dict):
        try:
            return json.dumps(action, sort_keys=True, separators=(",", ":"))
        except Exception:
            return str(action)
    return str(action)


def _action_name(action: Any) -> str:
    if isinstance(action, dict):
        farmer = action.get("farmer")
        if isinstance(farmer, list) and farmer:
            return str(farmer[0])
        return "DICT"
    return str(action).split(" ", 1)[0]


def summarize(path: str, obj: Any) -> ReplaySummary:
    steps = _find_steps(obj) or []
    players = max((len(s) for s in steps if isinstance(s, list)), default=0)
    counts: dict[int, Counter[str]] = {i: Counter() for i in range(players)}
    per_player: dict[int, list[str]] = {i: [] for i in range(players)}
    trace_parts: list[str] = []
    final_rewards: list[float | None] = [None] * players

    for turn, row in enumerate(steps):
        if not isinstance(row, list):
            continue
        for pid, state in enumerate(row):
            if not isinstance(state, dict):
                continue
            action = state.get("action")
            name = _action_name(action)
            counts[pid][name] += 1
            if len(per_player[pid]) < 40:
                per_player[pid].append(name)
            trace_parts.append(f"{turn}:{pid}:{_norm_action(action)}")
            reward = state.get("reward")
            if reward is not None:
                try:
                    final_rewards[pid] = float(reward)
                except (TypeError, ValueError):
                    pass

    trace = "|".join(trace_parts)
    digest = hashlib.sha256(trace.encode("utf-8")).hexdigest()
    early = ";".join(
        f"p{pid}:" + ",".join(per_player[pid][:24]) for pid in sorted(per_player)
    )
    early_sig = hashlib.sha256(early.encode("utf-8")).hexdigest()[:16]

    match = re.search(r"(?:episode|EPISODE)[-_](\d+)", path)
    episode_id = match.group(1) if match else None
    return ReplaySummary(
        path=path,
        episode_id=episode_id,
        steps=len(steps),
        players=players,
        final_rewards=final_rewards,
        action_counts={pid: dict(c) for pid, c in counts.items()},
        early_signature=early_sig,
        action_hash=digest,
        seat0_first_actions=per_player.get(0, [])[:40],
        seat1_first_actions=per_player.get(1, [])[:40],
    )


def to_dict(summary: ReplaySummary) -> dict[str, Any]:
    return asdict(summary)
