from kaggriculture_lab.replay import summarize


def test_summarize_basic():
    obj = {
        "steps": [
            [
                {"action": {"farmer": ["PASS"]}, "reward": 1},
                {"action": {"farmer": ["NORTH"]}, "reward": 0},
            ],
            [
                {"action": {"farmer": ["HARVEST"]}, "reward": 10},
                {"action": {"farmer": ["PASS"]}, "reward": 8},
            ],
        ]
    }
    s = summarize("episode-123-replay.json", obj)
    assert s.episode_id == "123"
    assert s.steps == 2
    assert s.players == 2
    assert s.action_counts[0]["PASS"] == 1
    assert s.action_counts[0]["HARVEST"] == 1
    assert s.final_rewards == [10.0, 8.0]
