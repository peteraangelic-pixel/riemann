from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from kaggriculture_lab.io import iter_json_files
from kaggriculture_lab.replay import summarize


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="data/replays")
    ap.add_argument("--output", default="artifacts/replay_fingerprints.csv")
    args = ap.parse_args()
    root = ROOT / args.input
    rows = []
    for path in iter_json_files(root):
        obj = json.loads(path.read_text(encoding="utf-8"))
        s = summarize(str(path.relative_to(ROOT)), obj)
        for pid in range(s.players):
            counts = s.action_counts.get(pid, {})
            rows.append({
                "path": s.path,
                "episode_id": s.episode_id,
                "player": pid,
                "steps": s.steps,
                "final_reward": s.final_rewards[pid] if pid < len(s.final_rewards) else None,
                "early_signature": s.early_signature,
                "action_hash": s.action_hash,
                "PASS": counts.get("PASS", 0),
                "NORTH": counts.get("NORTH", 0),
                "SOUTH": counts.get("SOUTH", 0),
                "EAST": counts.get("EAST", 0),
                "WEST": counts.get("WEST", 0),
                "WATER": counts.get("WATER", 0),
                "HARVEST": counts.get("HARVEST", 0),
                "PLANT": counts.get("PLANT", 0),
                "FERTILIZE": counts.get("FERTILIZE", 0),
            })
    out = ROOT / args.output
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]) if rows else ["path"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {len(rows)} player fingerprints -> {out}")


if __name__ == "__main__":
    main()
