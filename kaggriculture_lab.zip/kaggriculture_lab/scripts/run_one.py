from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    from kaggle_environments import make

    ap = argparse.ArgumentParser()
    ap.add_argument("agent1")
    ap.add_argument("agent2")
    ap.add_argument("--seed", type=int, default=20260906)
    ap.add_argument("--out")
    args = ap.parse_args()

    env = make("kaggriculture", configuration={"episodeSteps": 720, "seed": args.seed}, debug=True)
    env.run([args.agent1, args.agent2])
    final = env.steps[-1]
    result = {
        "seed": args.seed,
        "resolved_seed": env.info.get("seed"),
        "agents": [args.agent1, args.agent2],
        "rewards": [getattr(s, "reward", None) for s in final],
        "statuses": [getattr(s, "status", None) for s in final],
    }
    print(json.dumps(result, indent=2, default=str))
    if args.out:
        Path(args.out).write_text(json.dumps(result, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
