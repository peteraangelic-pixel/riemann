from __future__ import annotations

import argparse
import subprocess
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]


def main():
    ap = argparse.ArgumentParser(description="Save the current Kaggriculture leaderboard snapshot")
    ap.add_argument("--output", default="artifacts/leaderboard.txt")
    args = ap.parse_args()
    cmd = ["kaggle", "competitions", "leaderboard", "kaggriculture", "-s"]
    proc = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True)
    if proc.returncode != 0:
        print(proc.stderr, file=sys.stderr)
        raise SystemExit(proc.returncode)
    out = ROOT / args.output
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(proc.stdout, encoding="utf-8")
    print(out)


if __name__ == "__main__":
    main()
