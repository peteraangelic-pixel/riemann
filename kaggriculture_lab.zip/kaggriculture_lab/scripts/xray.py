from __future__ import annotations

import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def find_steps(obj):
    if isinstance(obj, dict):
        steps = obj.get("steps")
        if isinstance(steps, list):
            return steps
        for v in obj.values():
            r = find_steps(v)
            if r is not None:
                return r
    elif isinstance(obj, list):
        for v in obj[:10]:
            r = find_steps(v)
            if r is not None:
                return r
    return None


def action_label(a):
    if isinstance(a, dict):
        f = a.get("farmer")
        return str(f) if f is not None else "{}"
    return str(a)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("replay")
    ap.add_argument("--player", type=int, default=0)
    ap.add_argument("--every", type=int, default=24)
    args = ap.parse_args()
    path = Path(args.replay)
    obj = json.loads(path.read_text(encoding="utf-8"))
    steps = find_steps(obj) or []
    print(f"Replay: {path} | steps={len(steps)} | player={args.player}")
    for turn, row in enumerate(steps):
        if not isinstance(row, list) or args.player >= len(row):
            continue
        state = row[args.player]
        if turn < 48 or turn % args.every == 0 or turn == len(steps) - 1:
            obs = state.get("observation", {}) if isinstance(state, dict) else {}
            print(f"{turn:4d} action={action_label(state.get('action') if isinstance(state, dict) else None)}")
            for key in ("day", "hour", "market", "private"):
                if key in obs and turn % args.every == 0:
                    val = obs[key]
                    txt = json.dumps(val, separators=(",", ":"))
                    print(f"      {key}: {txt[:400]}")


if __name__ == "__main__":
    main()
