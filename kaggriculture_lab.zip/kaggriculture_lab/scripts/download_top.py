from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SLUG = "nnmax/kaggriculture-top10-replay-archive"


def run(cmd: list[str]) -> None:
    print("+", " ".join(cmd))
    subprocess.run(cmd, check=True, cwd=ROOT)


def main() -> int:
    ap = argparse.ArgumentParser(description="Download and unpack the public Kaggriculture TOP replay archive")
    ap.add_argument("--dataset-slug", default=DEFAULT_SLUG)
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--keep-zip", action="store_true")
    args = ap.parse_args()

    raw = ROOT / "data" / "raw" / "archive"
    replay = ROOT / "data" / "replays"
    raw.mkdir(parents=True, exist_ok=True)
    replay.mkdir(parents=True, exist_ok=True)

    zip_path = raw / f"{args.dataset_slug.replace('/', '_')}.zip"
    if args.force:
        for p in replay.glob("**/*"):
            if p.is_file():
                p.unlink()

    cmd = ["kaggle", "datasets", "download", "-d", args.dataset_slug, "-p", str(raw), "-o"]
    run(cmd)

    zips = sorted(raw.glob("*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not zips:
        raise FileNotFoundError("Kaggle CLI finished but no .zip was found in data/raw/archive")
    archive = zips[0]
    print(f"Using archive: {archive}")

    with zipfile.ZipFile(archive) as z:
        z.extractall(replay)

    manifest = {
        "dataset_slug": args.dataset_slug,
        "archive": str(archive.relative_to(ROOT)),
        "files": sorted(str(p.relative_to(ROOT)) for p in replay.rglob("*") if p.is_file()),
    }
    (ROOT / "artifacts").mkdir(exist_ok=True)
    (ROOT / "artifacts" / "download_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )

    if not args.keep_zip:
        archive.unlink(missing_ok=True)
    print(f"Extracted {len(manifest['files'])} files to {replay}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
