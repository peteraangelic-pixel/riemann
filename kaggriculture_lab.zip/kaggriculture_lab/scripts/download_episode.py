from __future__ import annotations

import argparse
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def run(cmd):
    print("+", " ".join(cmd))
    subprocess.run(cmd, check=True, cwd=ROOT)


def main():
    ap = argparse.ArgumentParser(description="Download one or more public Kaggriculture replays")
    ap.add_argument("episode_ids", nargs="+")
    ap.add_argument("--out", default="data/replays")
    args = ap.parse_args()
    out = ROOT / args.out
    out.mkdir(parents=True, exist_ok=True)
    for episode_id in args.episode_ids:
        run(["kaggle", "competitions", "replay", str(episode_id), "-p", str(out)])


if __name__ == "__main__":
    main()
