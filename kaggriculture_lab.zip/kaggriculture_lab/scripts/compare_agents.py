from __future__ import annotations

import argparse
import json
from pathlib import Path
import statistics
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.run_league import _play, _summary


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("candidate")
    ap.add_argument("baseline")
    ap.add_argument("--games", type=int, default=500)
    ap.add_argument("--start-seed", type=int, default=20260906)
    args = ap.parse_args()
    rows = []
    for i in range(args.games):
        seed = args.start_seed + i
        rows.append(_play((seed, args.candidate, args.baseline, 0)))
        rows.append(_play((seed, args.candidate, args.baseline, 1)))
    print(json.dumps(_summary(rows), indent=2))


if __name__ == "__main__":
    main()
