from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from kaggriculture_lab.io import iter_json_files, sha256
from kaggriculture_lab.replay import summarize, to_dict


def main():
    root = ROOT / "data" / "replays"
    rows = []
    for path in iter_json_files(root):
        try:
            obj = json.loads(path.read_text(encoding="utf-8"))
            s = summarize(str(path.relative_to(ROOT)), obj)
            rows.append(to_dict(s) | {"sha256": sha256(path)})
        except Exception as exc:
            rows.append({"path": str(path.relative_to(ROOT)), "error": repr(exc)})
    out = ROOT / "artifacts" / "replay_inventory.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(rows, indent=2), encoding="utf-8")
    print(f"Indexed {len(rows)} JSON files -> {out}")
    for r in rows[:20]:
        if "error" in r:
            print("ERROR", r["path"], r["error"])
        else:
            print(r["path"], "steps=", r["steps"], "players=", r["players"], "early=", r["early_signature"])


if __name__ == "__main__":
    main()
