from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import csv
import importlib.util
import json
import os
from pathlib import Path
import statistics
import time

ROOT = Path(__file__).resolve().parents[1]


def _load_agent(path: str):
    p = Path(path).resolve()
    spec = importlib.util.spec_from_file_location(f"kg_agent_{p.stem}_{abs(hash(str(p)))}", p)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load agent: {p}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if not hasattr(mod, "agent"):
        raise AttributeError(f"{p} has no top-level agent(obs) function")
    return mod.agent


def _play(job):
    seed, candidate, opponent, seat = job
    from kaggle_environments import make

    cand_fn = _load_agent(candidate)
    opp_fn = opponent if opponent in {"random", "starter", "pass"} else _load_agent(opponent)
    agents = [cand_fn, opp_fn] if seat == 0 else [opp_fn, cand_fn]
    env = make("kaggriculture", configuration={"episodeSteps": 720, "seed": int(seed)}, debug=True)
    env.run(agents)
    final = env.steps[-1]
    rewards = [float(getattr(s, "reward", 0.0) or 0.0) for s in final]
    candidate_reward = rewards[seat]
    opponent_reward = rewards[1 - seat]
    return {
        "seed": seed,
        "seat": seat,
        "candidate": candidate,
        "opponent": opponent,
        "candidate_reward": candidate_reward,
        "opponent_reward": opponent_reward,
        "margin": candidate_reward - opponent_reward,
        "outcome": "win" if candidate_reward > opponent_reward else "loss" if candidate_reward < opponent_reward else "tie",
        "resolved_seed": env.info.get("seed"),
    }


def _summary(rows):
    n = len(rows)
    wins = sum(r["outcome"] == "win" for r in rows)
    losses = sum(r["outcome"] == "loss" for r in rows)
    ties = n - wins - losses
    margins = [r["margin"] for r in rows]
    return {
        "games": n,
        "wins": wins,
        "losses": losses,
        "ties": ties,
        "win_rate": wins / n if n else 0.0,
        "score_rate": (wins + 0.5 * ties) / n if n else 0.0,
        "mean_margin": statistics.mean(margins) if margins else 0.0,
        "median_margin": statistics.median(margins) if margins else 0.0,
        "min_margin": min(margins) if margins else 0.0,
        "p10_margin": sorted(margins)[max(0, int(0.10 * len(margins)) - 1)] if margins else 0.0,
    }


def main():
    ap = argparse.ArgumentParser(description="Parallel adaptive Kaggriculture league")
    ap.add_argument("--candidate", required=True)
    ap.add_argument("--opponent", action="append", required=True, help="name=path OR name=starter/random/pass OR just path")
    ap.add_argument("--games", type=int, default=100)
    ap.add_argument("--workers", type=int, default=min(16, os.cpu_count() or 1))
    ap.add_argument("--start-seed", type=int, default=20260906)
    ap.add_argument("--swap-seats", action="store_true")
    ap.add_argument("--output-prefix", default="league")
    args = ap.parse_args()

    opponents = []
    for raw in args.opponent:
        if "=" in raw:
            name, target = raw.split("=", 1)
        else:
            target = raw
            name = Path(raw).stem
        opponents.append((name, target))

    jobs = []
    for _, opp in opponents:
        for i in range(args.games):
            seed = args.start_seed + i
            jobs.append((seed, args.candidate, opp, 0))
            if args.swap_seats:
                jobs.append((seed, args.candidate, opp, 1))

    started = time.perf_counter()
    rows = []
    print(f"Running {len(jobs)} games using {args.workers} worker processes...")
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures = [pool.submit(_play, job) for job in jobs]
        for idx, fut in enumerate(as_completed(futures), 1):
            try:
                rows.append(fut.result())
            except Exception as exc:
                rows.append({"error": repr(exc)})
            if idx % 100 == 0 or idx == len(futures):
                elapsed = time.perf_counter() - started
                print(f"completed {idx}/{len(futures)} in {elapsed:.1f}s")

    grouped = {}
    for name, _ in opponents:
        good = [r for r in rows if r.get("opponent") == _ and "error" not in r]
        grouped[name] = _summary(good)

    payload = {
        "candidate": args.candidate,
        "games_per_opponent_per_seat": args.games,
        "swap_seats": args.swap_seats,
        "workers": args.workers,
        "start_seed": args.start_seed,
        "elapsed_seconds": time.perf_counter() - started,
        "opponents": grouped,
        "total": _summary([r for r in rows if "error" not in r]),
        "errors": [r for r in rows if "error" in r],
        "rows": rows,
    }
    out_dir = ROOT / "reports"
    out_dir.mkdir(exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    json_path = out_dir / f"{args.output_prefix}-{stamp}.json"
    csv_path = out_dir / f"{args.output_prefix}-{stamp}.csv"
    json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["seed", "seat", "opponent", "candidate_reward", "opponent_reward", "margin", "outcome", "resolved_seed"])
        writer.writeheader()
        for r in rows:
            if "error" not in r:
                writer.writerow(r)
    print(json.dumps(grouped, indent=2))
    print("JSON:", json_path)
    print("CSV :", csv_path)


if __name__ == "__main__":
    main()
